# devops-essentials-sample-app

This is a simple sample application intended to be used alongside the labs for DevOps Essentials.
